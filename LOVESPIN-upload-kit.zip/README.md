# LoveSpin – Spin Into Love

A standalone, private couples challenge game. No server runtime, database, external services, payments or advertisements are required. All assets load locally with relative URLs.

## Publish on cPanel
1. Upload **LOVESPIN-deploy.zip** into `public_html/lovespin/` using File Manager.
2. Extract it there. `index.html` must be directly inside `public_html/lovespin/`, alongside `src`, `assets` and `fonts`.
3. Open https://play2earn.world/lovespin/ . No npm installation or build command is needed on the hosting server.
4. If using the Play2Earn admin uploader instead, create a **locally hosted** game with slug **lovespin**, upload LOVESPIN-deploy.zip, choose the supplied cover, set display order to **0**, then publish. Do not upload the complete-project or upload-kit archive as a game build.

Use HTTPS. Refreshing the game opens its welcome screen with a saved-game button. This is a single-page game with no nested routes or rewrite dependency. No existing portal files need changing. For an update, replace only this game's runtime files; browser storage and portal metadata remain separate.

## Local preview and source
Run `node build.mjs`, then `node preview.mjs` from this project folder. Open http://127.0.0.1:5230/lovespin/ . Leave that process running while playing. Alternatively double-click Start-LOVESPIN.cmd if Node is installed or the bundled Codex runtime is available. The preview listens only on this computer.

Run `node --test src/engine.test.js` for the automated puzzle-free gameplay checks. No npm packages are required. Complete source is in `src`; `dist` is the ready-to-upload version. The production package uses native browser modules, optimized JPEG artwork, original SVG illustrations and a local font.

## Playing
Enter two names, choose one of five moods, and take turns spinning. Complete, skip, or exchange the revealed challenge. Ten rounds lead to an optional cooperative finale. Replay keeps your names. Space spins when no form or dialog is focused; all controls also work with keyboard navigation.

Every challenge is optional. Affection is off by default and appears only when both partners independently enable it. Long-distance mode excludes physical affection. Settings can change at any time. Scores and the Love Meter are entertainment, never relationship assessments or redeemable rewards.

Normal challenges award 10 points; Bonus and Double Dare award 20; Golden Hearts and rare golden spins award 50. Every third consecutive completion adds 5 points. Skips and exchanges deduct nothing. Skipping advances the turn; exchanging keeps it. A finale earns 20 points. Twelve segments have equal selection probability. Mystery Mix has an additional 4% golden-spin event. Recent challenges are avoided until the applicable filtered pool is exhausted, then the oldest available one can return.

Names, scores, comfort and audio settings stay in this browser's localStorage (`lovespin-v1`). Nothing is uploaded. Blocking storage disables persistence gracefully. Sound begins only after interaction; music is optional and generated locally with Web Audio. Reduced motion is available in Settings and respects the system preference. Haptics depend on browser support.

## Artwork and metadata
Use lovespin-cover.jpg for the directory card and lovespin-social.jpg (1200 × 630) for the featured banner/social preview. Original promotional artwork was generated specifically for this game; wheel, icons and interface are original SVG/CSS. DM Sans is distributed with its font license in fonts/LICENSE.txt. See GAME-METADATA.md for copy and QA.md for actual verification.

Modern Safari, Chrome, Edge and Firefox with ES modules, SVG and Web Audio are the intended browser family. Physical-device performance has not been benchmarked; no fixed frame-rate guarantee is made.
