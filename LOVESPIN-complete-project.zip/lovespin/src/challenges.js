// Each core mode has 40 individually written prompts. P = physical affection (both opt-ins required).
const text=`
sweet|say||Give your partner three compliments without using the words beautiful, cute or nice.
sweet|say||Describe one tiny thing your partner does that quietly improves your day.
sweet|say||Invent an award for your partner and deliver a twenty-second acceptance speech on their behalf.
sweet|say||Finish “I feel most at home with you when…” with a specific moment.
sweet|say||Tell your partner which ordinary Tuesday together you would happily relive.
sweet|say||Give your partner a compliment that has nothing to do with appearance or achievements.
sweet|say||Choose three words for your partner, then explain the least obvious one.
sweet|say||Describe your partner as the hero of a cozy novel. Include their surprising superpower.
sweet|say||Thank your partner for something they may not realize you noticed.
sweet|say||Say a kind sentence your partner can borrow on a difficult day.
sweet|do|P|Offer your partner a forehead kiss or a warm hug; let them choose, including neither.
sweet|do|P|If you both want to, hold hands for twenty seconds and name one thing you appreciate.
sweet|do|P|Ask whether your partner would enjoy a gentle shoulder squeeze. A kind word is an equal alternative.
sweet|do|P|Share a comfortable side hug for a few breaths, only if you both welcome it.
sweet|do||Write a six-word love note and read it as if it is a priceless poem.
sweet|do||Make a heart using your hands and show it to your partner or the camera.
sweet|do||Pick an imaginary flower for your partner and explain why that particular flower suits them.
sweet|do||Choose a song for a future date and tell your partner the exact scene you picture.
sweet|do||Draw a tiny doodle of your favorite shared routine. Let your partner guess it.
sweet|do||Take thirty seconds to plan one small act of kindness you can do for your partner this week.
sweet|ask||Ask which little tradition your partner would like the two of you to start.
sweet|ask||Ask your partner about a moment when they felt especially supported by you.
sweet|ask||Which first impression of each other turned out to be hilariously wrong? Share kindly.
sweet|ask||Ask which place, real or imaginary, feels like your relationship in one scene.
sweet|ask||Ask what tiny comfort your partner would put in an ideal care package.
sweet|ask||Choose a memory that deserves its own postcard. Describe the picture and the caption.
sweet|ask||Ask your partner which shared meal deserves a repeat performance.
sweet|ask||What did your partner say once that you still remember for a lovely reason?
sweet|ask||Ask what an unhurried afternoon together would look like right now.
sweet|ask||Ask which everyday sound reminds your partner of you, and why.
sweet|together||Together, build a three-item menu for your imaginary neighborhood cafe.
sweet|together||Take turns adding one sentence to a story about your perfect slow Sunday.
sweet|together||Each choose one shared memory and give it an affectionate movie title.
sweet|together||Invent a private greeting that works in person and across a video call.
sweet|together||Take turns saying “more of this” about three simple things you enjoy together.
sweet|together||Create a two-line promise about a small, realistic way to care for each other this week.
sweet|together||Together, design a cozy corner using only five imaginary objects.
sweet|together||Each name one thing the other taught you, even if it was a better way to make toast.
sweet|together||Pick a shared theme song for today and explain your choices before agreeing on one.
sweet|together||Create the title and dedication for a photo album of this chapter of your lives.
laugh|say||Give a dramatic weather forecast for your partner's snack cupboard.
laugh|say||Introduce your partner like a legendary athlete entering a championship of everyday chores.
laugh|say||Read an imaginary shopping list in the voice of a very serious royal announcer.
laugh|say||Deliver a twenty-second speech defending the rights of missing socks.
laugh|say||Pretend you are a nature-documentary narrator observing your partner choosing a movie.
laugh|say||Sell your partner an invisible spoon using your most enthusiastic advertisement voice.
laugh|say||Explain why your sofa should be elected mayor, without breaking character.
laugh|say||Give a heartfelt farewell speech to the last slice of pizza.
laugh|say||Narrate your last ordinary commute as an unnecessarily expensive action trailer.
laugh|say||Invent a wildly overqualified job title for your partner's most ordinary talent.
laugh|do||Mime making breakfast in zero gravity while your partner guesses the dish.
laugh|do||Make three increasingly ridiculous but comfortable victory poses. Let your partner name them.
laugh|do||Draw your partner as a friendly household appliance and explain its premium features.
laugh|do||Act out a slow-motion celebration for finding your keys. Keep your feet safely on the floor.
laugh|do||Balance an imaginary crown and give a regal nod to five imaginary subjects.
laugh|do||Mime an argument between a stubborn umbrella and a polite raincloud.
laugh|do||Make the face of someone discovering their plant has written a better autobiography than they have.
laugh|do||Demonstrate your signature dance using only your hands for fifteen seconds.
laugh|do||Create a three-second commercial for a completely useless imaginary invention.
laugh|do||Pose for the imaginary cover of “People Who Finally Replied to That Email.”
laugh|ask||If your partner were a slightly inconvenient superpower, what would the superpower do?
laugh|ask||What is the least intimidating name for a very dramatic villain? Nominate one each.
laugh|ask||Which household object would be the worst roommate, and what would its main complaint be?
laugh|ask||If your relationship had a loading-screen tip, what would it say?
laugh|ask||What completely harmless thing deserves a tiny ceremonial parade?
laugh|ask||If your fridge could write a review of you, what would the headline be?
laugh|ask||Which fictional animal would be the best host for your next dinner party?
laugh|ask||What is the funniest honest name for your current collection of open browser tabs?
laugh|ask||If you opened a museum of small daily inconveniences, what would be the main exhibit?
laugh|ask||What would your partner be famous for in a town populated entirely by houseplants?
laugh|together||Build an imaginary robot together: each person supplies one silly feature and one sound.
laugh|together||Take turns adding one word to a very dramatic restaurant complaint about invisible soup.
laugh|together||Invent a secret handshake using only gestures you can both do comfortably on camera.
laugh|together||Hold a thirty-second debate about whether a biscuit needs a passport to become dessert.
laugh|together||Each draw an imaginary mascot for your household. Combine the two into one ridiculous creature.
laugh|together||Create a two-line jingle for your future professional napping business.
laugh|together||Play a round of silent charades: one person mimes an emotion, the other invents its movie title.
laugh|together||Together, give an imaginary pet rock a name, a hobby and an outrageous professional biography.
laugh|together||Take turns giving the most exaggerated polite reaction to a gift of imaginary air.
laugh|together||Write a three-sentence adventure starring yourselves and an emotionally complicated toaster.
flirty|say||Deliver your cheesiest original pickup line, then give it a very serious review out of five stars.
flirty|say||Give your partner a playful compliment as if you are meeting them at a glamorous party.
flirty|say||Say “I would choose you again” in the voice of a charmingly nervous romantic-comedy character.
flirty|say||Describe the exact moment your partner went from interesting to irresistible company.
flirty|say||Invent a flirty nickname that is kind, welcome and delightfully over-the-top.
flirty|say||Tell your partner which small habit of theirs still gives you butterflies.
flirty|say||Give a thirty-second review of your partner's smile as if it is a five-star destination.
flirty|say||Make up the opening line of a love letter written by your future self.
flirty|say||Describe a completely ordinary errand that would be more fun as a date with your partner.
flirty|say||Whisper, or softly say across the call, one sweet invitation for a future date.
flirty|do|P|Ask whether your partner would enjoy a gentle hand kiss. Only do it after an enthusiastic yes.
flirty|do|P|If you both welcome it, share one brief kiss and then trade a compliment. Kind words are an equal alternative.
flirty|do|P|Invite your partner to choose a forehead kiss or a cuddle, with a no-touch alternative always welcome.
flirty|do|P|Ask if your partner would like a slow, comfortable hand squeeze while you say something affectionate.
flirty|do||Hold comfortable eye contact, or look toward the camera, for fifteen seconds. Laughing is allowed.
flirty|do||Create your best playful “hello again” wave for a date across a crowded room.
flirty|do||Write a flirty message of exactly seven words and read it aloud with theatrical confidence.
flirty|do||Choose an outfit color for your imaginary red-carpet date and explain the vibe.
flirty|do||Show your most charming smile, then ruin the dramatic moment with a deliberately terrible pun.
flirty|do||Invent an invitation to a very exclusive date at your own kitchen table.
flirty|ask||Ask what tiny detail of a date makes your partner feel especially wanted and appreciated.
flirty|ask||Which of your shared moments would make the best meet-cute scene in a romantic comedy?
flirty|ask||Ask your partner which song would play when the two of you walk into a room together.
flirty|ask||What was the most unexpectedly charming thing you learned about your partner?
flirty|ask||Ask which harmless romantic cliche your partner would secretly enjoy trying.
flirty|ask||If you had one hour for a surprise date, what would your partner hope you planned?
flirty|ask||Ask your partner which version of “date night at home” sounds most tempting today.
flirty|ask||What compliment from your partner has stayed with you longer than expected?
flirty|ask||Ask what makes a goodbye feel warm and connected, in person or across a call.
flirty|ask||Which fictional backdrop would you choose for an absurdly glamorous first date together?
flirty|together||Take turns completing “A date with you should always include…” with three playful ideas.
flirty|together||Recreate your first conversation using deliberately exaggerated romantic-comedy dialogue.
flirty|together||Design a fictional hotel suite for a cozy getaway: each add one lovely and one ridiculous feature.
flirty|together||Each deliver a five-word flirtation. Together, turn them into one gloriously cheesy sentence.
flirty|together||Plan a pretend date using a random color, an ordinary snack and one shared song.
flirty|together||Take turns explaining why the other deserves the lead role in your imaginary romantic comedy.
flirty|together||Create a friendly three-option date-night menu and each choose what sounds best without pressure.
flirty|together||Make up a romantic movie title for tonight, then act out its very innocent closing line.
flirty|together||Take turns offering a sweet compliment and an intentionally silly wink or wave.
flirty|together||Each name a small way you would like to feel appreciated this week; choose one idea to try together.
deep|say||Finish “One way I have grown since knowing you is…” with a specific example.
deep|say||Share a value you learned growing up that you would like to bring into your shared life.
deep|say||Describe a recent moment when you felt proud of the way you handled something together.
deep|say||Name one quality in your partner that makes a difficult day feel more manageable.
deep|say||Share a small dream you rarely mention because it feels delightfully ordinary.
deep|say||Describe what being listened to looks like for you, using one practical example.
deep|say||Tell your partner about a kind gesture from someone that changed your outlook.
deep|say||Name a chapter of your life that taught you something useful about caring for others.
deep|say||Share something you would like to make more room for in the next month.
deep|say||Finish “A peaceful life, to me, includes…” with three ordinary details.
deep|do||Take twenty quiet seconds to think of one question you have been curious to ask kindly, then ask it.
deep|do||Write a short message to your future selves and read it together. No private details need be saved.
deep|do||Choose a symbol for the chapter you are in now and explain what it represents.
deep|do||Draw a simple map of a place that matters to you and explain one meaningful corner.
deep|do||List three things within reach that represent comfort, possibility and connection.
deep|do||Create a one-sentence intention for how you would like to show up for each other this week.
deep|do||Choose one routine you could make gentler and propose a small, realistic change.
deep|do||Make an imaginary time capsule containing one memory, one hope and one everyday object.
deep|do||Take a calm breath, then tell your partner one thing you would like them to understand about your week.
deep|do||Think of a place you have never visited. Explain what kind of experience you hope to find there.
deep|ask||Ask which family or community tradition your partner would like to keep, change or invent anew.
deep|ask||What does a genuinely restful day look like for your partner right now?
deep|ask||Ask what a small, meaningful success would look like in the next three months.
deep|ask||Which shared memory feels different now that you understand each other better?
deep|ask||Ask how your partner prefers to receive support: company, practical help, listening or space.
deep|ask||What is something you once thought was important that matters less to you now?
deep|ask||Ask which place has shaped your partner's sense of belonging, and how.
deep|ask||Which skill or experience would you enjoy learning together without needing to be good at it?
deep|ask||Ask what your partner hopes the two of you will laugh about when remembering this year.
deep|ask||What is a gentle way the two of you could reconnect after a busy stretch?
deep|together||Take turns describing one shared hope. Find a small step that would help both of you move toward it.
deep|together||Build a future weekend together, one detail at a time, balancing rest and adventure.
deep|together||Each name one thing to keep, one thing to simplify and one thing to try in your shared routines.
deep|together||Create a tiny shared bucket list with one free idea, one local idea and one someday idea.
deep|together||Take turns finishing “I feel supported when…” and listen without needing to solve anything.
deep|together||Together, choose three words you would like to describe the next chapter of your relationship.
deep|together||Each tell a different part of the story of how you met. Enjoy the places where the memories differ.
deep|together||Imagine a celebration five years from now. What ordinary things would you hope are still part of it?
deep|together||Each share one way you have noticed the other growing, and one kind wish for their next chapter.
deep|together||Create a two-sentence agreement about making space for both togetherness and individual interests.
`;
export const CHALLENGES=text.trim().split('\n').map((line,i)=>{const[mode,topic,gate,prompt]=line.split('|');return{id:`c${String(i+1).padStart(3,'0')}`,mode,topic,physical:gate==='P',text:prompt}});
export const GOLDEN=[
 ['sweet','Together, create a five-line love letter: alternate lines and finish the last line at the same time.'],
 ['sweet','Build an imaginary gallery of three favorite shared moments. Each take a turn giving a short tour.'],
 ['sweet','Each offer one compliment, one thank-you and one small wish. Together, choose a name for this golden moment.'],
 ['sweet','Design a tiny tradition for your next reunion or quiet evening. Each contribute a detail you would genuinely enjoy.'],
 ['laugh','Together, produce a thirty-second awards show for your most ridiculous shared achievement. Include two acceptance speeches.'],
 ['laugh','Invent a completely harmless couple superpower, then perform its overdramatic origin story together.'],
 ['laugh','Create a very silly tourist advertisement for the room you are in, taking turns as the enthusiastic presenters.'],
 ['laugh','Together, improvise the trailer for a romantic comedy starring a pair of lost slippers. Give it an unforgettable title.'],
 ['flirty','Together, script a brand-new meet-cute with three lines each. Finish by inviting the other on a real, low-pressure date.'],
 ['flirty','Take turns giving a sweet compliment, suggesting a cozy date and making one playful promise you can realistically keep.'],
 ['flirty','Design your imaginary perfect evening together, alternating one charming detail with one wonderfully silly detail.'],
 ['flirty','Create an affectionate duet of spoken lines: each say three things that make time together feel special.'],
 ['deep','Together, create a short letter to your future selves: one memory to keep, one value to protect and one hope to explore.'],
 ['deep','Take turns sharing a dream, then offer one practical way you could support each other without taking over.'],
 ['deep','Imagine telling the story of this chapter years from now. Each choose one moment and one lesson you hope to remember.'],
 ['deep','Together, design a gentle ritual for reconnecting after busy weeks. Include a choice for quiet days and a choice for energetic ones.']
].map(([mode,text],i)=>({id:`g${i+1}`,mode,topic:'together',physical:false,text}));
export const FINALES=[
 'Together, name one moment from this game you want to remember, one thing you appreciate right now, and one small plan you look forward to. Give your evening a title.',
 'Create a tiny time capsule aloud: each contribute a favorite moment from today, a kind sentence for the other and a wish for your next date.',
 'Take turns finishing these three lines: “Tonight I noticed…”, “I appreciate…”, and “Next time, let’s…”. Finish with your own shared sign-off.',
 'Together, invent a new tradition inspired by tonight. Decide its name, one simple step and a time you would both like to try it.',
 'Each choose a song title, a memory and a kind promise for the week ahead. Together, turn them into the dedication for your next chapter.',
 'Make a two-person highlight reel: each describe one funny moment, one warm moment and one ordinary thing you are looking forward to doing together.'
];
