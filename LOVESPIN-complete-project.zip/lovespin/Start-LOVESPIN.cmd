@echo off
cd /d "%~dp0"
set "LOVESPIN_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%LOVESPIN_NODE%" set "LOVESPIN_NODE=node"
start "" "http://127.0.0.1:5230/lovespin/"
"%LOVESPIN_NODE%" preview.mjs
pause
